var searchData=
[
  ['iter_5fmax',['iter_max',['../fractal_8cpp.html#a3eaef5ac82eff28529969e808644c76c',1,'fractal.cpp']]]
];
