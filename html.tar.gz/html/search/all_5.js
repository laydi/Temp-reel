var searchData=
[
  ['reel',['reel',['../fractal_8cpp.html#ae595fba1f9e1eb4d8a2ca39e2f091228',1,'fractal.cpp']]]
];
