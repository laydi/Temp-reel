var searchData=
[
  ['wid',['WID',['../fractal_8cpp.html#a35eae9266093cf5bc8cfd5925c2ea3e0',1,'fractal.cpp']]]
];
