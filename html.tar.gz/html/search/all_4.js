var searchData=
[
  ['nb_5fthread',['NB_THREAD',['../fractal_8cpp.html#a75714185144c45f14d78b9a7c80a5a64',1,'fractal.cpp']]]
];
